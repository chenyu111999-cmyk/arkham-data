#!/usr/bin/env bash
#
# AH 卡牌助手 · 社区牌组服务 一键安装
#
#   sudo bash install.sh              # 默认端口 8443
#   sudo bash install.sh --port 9000
#
# 做的事：装 Node 22（如果缺）→ 拷文件到 /opt/arkham-api → 建服务账号
#        → 生成管理密钥 → 装 systemd 服务 → 启动 → 自检
# 重复运行安全：已有数据库和 ADMIN_KEY 不会被覆盖。
set -euo pipefail

APP_DIR=/opt/arkham-api
SERVICE=arkham-api
PORT=8443

while [ $# -gt 0 ]; do
  case "$1" in
    --port) PORT="$2"; shift 2 ;;
    -h|--help) sed -n '2,12p' "$0"; exit 0 ;;
    *) echo "未知参数：$1"; exit 2 ;;
  esac
done

say() { printf '\033[36m==>\033[0m %s\n' "$*"; }
die() { printf '\033[31m错误：\033[0m %s\n' "$*" >&2; exit 1; }

[ "$(id -u)" = "0" ] || die "需要 root 权限，请用：sudo bash install.sh"
command -v systemctl >/dev/null || die "这台机器没有 systemd，本脚本不适用"

# ---------- 1. Node ----------
# 服务器上可能同时有旧版 /usr/bin/node 和新版 /usr/local/bin/node，
# 只认 PATH 会摸错，所以先看绝对路径。
node_major() { "$1" -p "process.versions.node.split('.')[0]" 2>/dev/null || echo 0; }

need_node=1
if [ -x /usr/local/bin/node ] && [ "$(node_major /usr/local/bin/node)" -ge 22 ]; then
  need_node=0
  say "已有 Node $(/usr/local/bin/node -v)（/usr/local/bin/node），跳过安装"
elif command -v node >/dev/null 2>&1 && [ "$(node_major "$(command -v node)")" -ge 22 ]; then
  need_node=0
  say "已有 Node $(node -v)，跳过安装"
elif command -v node >/dev/null 2>&1; then
  say "现有 Node $(node -v) 太旧，需要 22 以上"
fi

if [ "$need_node" = "1" ]; then
  case "$(uname -m)" in
    x86_64)  NARCH=x64 ;;
    aarch64) NARCH=arm64 ;;
    *) die "不支持的 CPU 架构：$(uname -m)" ;;
  esac

  NVER=v22.13.1
  TARBALL="node-$NVER-linux-$NARCH.tar.xz"
  # npmmirror 是国内镜像，比 nodejs.org 快一个数量级
  URL="https://registry.npmmirror.com/-/binary/node/$NVER/$TARBALL"

  say "下载 Node $NVER（$NARCH）…"
  if ! curl -fSL --connect-timeout 15 -m 300 "$URL" -o "/tmp/$TARBALL"; then
    die "下载失败。请手动装 Node 22 后重跑：https://nodejs.org/zh-cn/download"
  fi

  say "解压到 /usr/local …"
  tar -xJf "/tmp/$TARBALL" -C /usr/local --strip-components=1
  rm -f "/tmp/$TARBALL"

  if [ ! -x /usr/local/bin/node ]; then
    die "解压后找不到 /usr/local/bin/node，请手动检查"
  fi
  if [ "$(node_major /usr/local/bin/node)" -lt 22 ]; then
    die "/usr/local/bin/node 版本仍低于 22，可能被其它安装覆盖了"
  fi
  say "已安装 $(/usr/local/bin/node -v) 到 /usr/local/bin"
fi

# ---------- 2. 复制程序 ----------
NODE_DIR="$(cd "$(dirname "$0")" && pwd)"
SRC="$(cd "$NODE_DIR/.." && pwd)"
[ -f "$SRC/worker.js" ] || die "包不完整：$SRC 下缺 worker.js（请在解压后的 arkham-api 目录里运行）"

say "安装到 $APP_DIR …"
mkdir -p "$APP_DIR/node/data"

for f in worker.js schema.sql seed.sql package.json; do
  [ -f "$SRC/$f" ] && cp -f "$SRC/$f" "$APP_DIR/$f"
done
cp -f "$SRC/node/d1.mjs" "$SRC/node/server.mjs" "$SRC/node/start.sh" "$APP_DIR/node/"
chmod +x "$APP_DIR/node/start.sh"

# ---------- 3. 服务账号 ----------
if ! id -u arkham >/dev/null 2>&1; then
  say "创建服务账号 arkham（无登录权限）"
  useradd --system --shell /usr/sbin/nologin --home-dir "$APP_DIR" arkham 2>/dev/null || true
fi
# 程序文件归 root（服务账号不能改代码），只有数据目录可写
chown -R root:root "$APP_DIR"
chown -R arkham:arkham "$APP_DIR/node/data"
chmod 750 "$APP_DIR/node/data"

# ---------- 4. 配置 ----------
ENV_FILE="$APP_DIR/env"
if [ -f "$ENV_FILE" ] && grep -q '^ADMIN_KEY=.\+' "$ENV_FILE" 2>/dev/null; then
  say "沿用已有的 ADMIN_KEY"
  ADMIN_KEY=$(grep '^ADMIN_KEY=' "$ENV_FILE" | cut -d= -f2-)
else
  # 24 位随机，去掉符号里容易被误读的
  ADMIN_KEY=$(head -c 32 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 24)
  say "生成新的管理密钥"
fi

cat > "$ENV_FILE" <<EOF
PORT=$PORT
HOST=0.0.0.0
DB_PATH=$APP_DIR/node/data/arkham.db
ADMIN_KEY=$ADMIN_KEY
EOF
# 640 root:arkham —— 服务账号要读得到（手工启动时靠它拿 PORT/ADMIN_KEY），
# 但其它用户不行
chmod 640 "$ENV_FILE"
chown root:arkham "$ENV_FILE" 2>/dev/null || chown root:root "$ENV_FILE"

# ---------- 5. 防火墙 ----------
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
  say "放行 ufw 端口 $PORT"
  ufw allow "$PORT"/tcp >/dev/null 2>&1 || true
fi
if command -v firewall-cmd >/dev/null 2>&1 && firewall-cmd --state >/dev/null 2>&1; then
  say "放行 firewalld 端口 $PORT"
  firewall-cmd --permanent --add-port="$PORT"/tcp >/dev/null 2>&1 || true
  firewall-cmd --reload >/dev/null 2>&1 || true
fi

# ---------- 6. systemd ----------
say "安装 systemd 服务"
cp -f "$SRC/node/arkham-api.service" "/etc/systemd/system/$SERVICE.service"
systemctl daemon-reload
systemctl enable "$SERVICE" >/dev/null 2>&1 || true
systemctl restart "$SERVICE"

# ---------- 7. 自检 ----------
say "等待服务起来…"
ok=0
for i in $(seq 1 20); do
  sleep 1
  if curl -sS -m 3 "http://127.0.0.1:$PORT/health" 2>/dev/null | grep -q '"ok":true'; then
    ok=1
    break
  fi
done

if [ "$ok" != "1" ]; then
  echo
  echo "服务没能正常启动，最近日志："
  journalctl -u "$SERVICE" -n 30 --no-pager || true
  die "请把上面的输出发给我"
fi

PUBIP=$(curl -sS -m 5 https://4.ipw.cn 2>/dev/null || curl -sS -m 5 https://ipinfo.io/ip 2>/dev/null || echo "你的公网IP")

cat <<EOF

────────────────────────────────────────────
  安装完成，服务已在运行
────────────────────────────────────────────

  接口地址    http://$PUBIP:$PORT
  健康检查    http://$PUBIP:$PORT/health
  审核页      http://$PUBIP:$PORT/admin?key=$ADMIN_KEY

  管理密钥    $ADMIN_KEY
              （已存于 $ENV_FILE，勿外传）

  数据文件    $APP_DIR/node/data/arkham.db
  看日志      journalctl -u $SERVICE -f
  重启        systemctl restart $SERVICE
  备份        bash $APP_DIR/node/backup.sh

────────────────────────────────────────────
  还差一步：在云厂商控制台的「防火墙」里
  放行 TCP $PORT，否则外网访问不通。
────────────────────────────────────────────
EOF
