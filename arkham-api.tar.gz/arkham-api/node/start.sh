#!/usr/bin/env bash
# 启动脚本。
#
# 不依赖 PATH：systemd 和 runuser 给的 PATH 不一定和登录 shell 一样，
# 服务器上常常同时存在 /usr/bin/node（apt 装的旧版）和 /usr/local/bin/node（新版），
# 走 PATH 有可能摸到旧那个。这里优先用 /usr/local/bin/node。
#
# Node 22 需要显式打开 sqlite；23 以后默认启用。
set -euo pipefail
cd "$(dirname "$0")"

if [ -x /usr/local/bin/node ]; then
  NODE_BIN=/usr/local/bin/node
elif command -v node >/dev/null 2>&1; then
  NODE_BIN=$(command -v node)
else
  echo "没找到 node，请先运行 install.sh" >&2
  exit 1
fi

major=$("$NODE_BIN" -p "process.versions.node.split('.')[0]" 2>/dev/null || echo 0)
if [ "$major" -lt 22 ]; then
  echo "Node 版本过低（$NODE_BIN 是 $("$NODE_BIN" -v)），需要 22 以上" >&2
  exit 1
fi

if [ "$major" -lt 23 ]; then
  exec "$NODE_BIN" --experimental-sqlite server.mjs
fi
exec "$NODE_BIN" server.mjs
