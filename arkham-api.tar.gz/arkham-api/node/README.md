# 社区牌组服务 · 自建部署（国内服务器）

同一份 `worker.js`，既跑 Cloudflare Workers，也跑普通 Node 服务器。
换到这里不需要改任何业务代码 —— `node/d1.mjs` 把 D1 接口模拟掉了。

---

## 为什么不用 Cloudflare

实测国内 DNS 解析 `*.workers.dev` 返回 `31.13.88.26`，是 Facebook 的 IP。
这说明域名在解析阶段就被污染了，不是"慢"，是根本连不上。

---

## 一、买机器

| 项 | 建议 |
|---|---|
| 厂商 | 腾讯云轻量应用服务器 / 阿里云 ECS 都可以 |
| 配置 | 2 核 2G 起步，这套服务实际占用不到 200MB |
| 系统 | **Ubuntu 22.04 LTS**（最强兼容；Debian 11+ 也行） |
| 地域 | 上海 / 广州 / 北京，离用户近 |
| 带宽 | 3M 足够。每天几千次请求也就几十 MB |

首年通常 68–99 元，续费按官网价。学生认证后更便宜。

> 如果你想用域名访问，那台机器上的 80/443 端口**必须完成 ICP 备案**才会放通。
> 用 `IP + 非标端口`（本方案默认 8443）不需要备案，直接能通。

---

## 二、装上去（三条命令）

在服务器上执行（控制台的网页终端也行）：

```bash
curl -fL -o arkham-api.tar.gz \
  "https://gh-proxy.com/https://raw.githubusercontent.com/chenyu111999-cmyk/arkham-data/main/arkham-api.tar.gz"

tar xzf arkham-api.tar.gz
sudo bash arkham-api/node/install.sh
```

脚本会自动完成：装 Node 22 → 拷到 `/opt/arkham-api` → 建无登录权限的服务账号
→ 生成 24 位管理密钥 → 装 systemd 服务 → 启动 → 自检。

跑完会打印类似：

```
接口地址    http://1.2.3.4:8443
健康检查    http://1.2.3.4:8443/health
审核页      http://1.2.3.4:8443/admin?key=Xk9mQ2vL7pR4tW1n
```

**把审核页地址存下来**，投稿要靠它放行。密钥同时写在 `/opt/arkham-api/env`。

---

## 三、开端口（必做，否则外网不通）

云厂商的防火墙上默认只开 22/80/443，**8443 是关的**。

- **腾讯云轻量**：控制台 → 服务器 → 防火墙 → 添加规则 → TCP:8443
- **阿里云 ECS**：控制台 → 安全组 → 入方向 → 添加 8443

本机的 `ufw` / `firewalld` 脚本已经顺手放行了，云控制台这一层它管不到。

开完之后在**你手机上**打开浏览器试：

```
http://你的IP:8443/health
```

看到 `{"ok":true,"service":"arkham-community","v":2}` 就通了。

---

## 四、接进 App

在开发机上（不是服务器）：

```bash
cd /workspace/ArkhamHelper
python3 tools/set_api.py http://你的IP:8443 --build
```

`set_api.py` 会同时做两件事：

1. 改 `VoteApi.BASE`
2. 往 `res/xml/network_security_config.xml` 里追加一条**只放行这个 IP** 的明文例外

Android 9 起默认禁止明文 HTTP，不做第二步的话 App 会直接抛异常。
放行范围限制到单个 host，其它域名依旧强制 HTTPS。

然后把新包发出去即可。

---

## 五、日常运维

```bash
# 看实时日志（不记 IP，只记方法、路径、状态码、耗时）
journalctl -u arkham-api -f

# 重启 / 停止 / 看状态
systemctl restart arkham-api
systemctl stop arkham-api
systemctl status arkham-api

# 备份（VACUUM INTO，WAL 下比 cp 安全，顺带压实）
sudo bash /opt/arkham-api/node/backup.sh
# → /opt/arkham-api/backup/arkham-20261104-1230.db.gz
```

数据全在 `/opt/arkham-api/node/data/arkham.db` 一个文件里，拷走就是全量备份。

建议加个定时任务：

```bash
sudo crontab -e
# 每天凌晨 4 点备份
0 4 * * * bash /opt/arkham-api/node/backup.sh >/dev/null 2>&1
```

---

## 六、从 Cloudflare 迁过来

如果之前在 D1 里已经有数据，导出成 SQL 再导入：

```bash
# 在 Cloudflare 侧导出
wrangler d1 export arkham-db --remote --output=dump.sql

# 传到服务器，然后
node -e 'const{DatabaseSync}=require("node:sqlite");const fs=require("fs");
const d=new DatabaseSync("/opt/arkham-api/node/data/arkham.db");
d.exec(fs.readFileSync("dump.sql","utf8"));d.close()'
```

反过来（本地 → Cloudflare）也一样，`sqlite3 arkham.db .dump` 就行。

---

## 七、常见问题

**Q：`/health` 在服务器上 curl 得通，手机打不开？**

云控制台的防火墙没开 8443。这是最常见的一个，占九成。

**Q：换服务器了，IP 变了怎么办？**

搬走 `data/arkham.db`，然后重跑 `set_api.py` 换新地址、重新发版。
现网已装的旧版会连不上新服务器 —— 所以**尽量买固定公网 IP**，别用按量实例。

**Q：能不能上 HTTPS？**

可以，但要有域名。有域名 + 备案后，用 Caddy 反代最省事：

```bash
apt install -y caddy
cat >/etc/caddy/Caddyfile <<'EOF'
vote.你的域名.com {
    reverse_proxy 127.0.0.1:8443
}
EOF
systemctl reload caddy
```

同时把 `HOST` 改成 `127.0.0.1`，让 8443 只监听本机，外网只走 443。
之后 `set_api.py https://vote.你的域名.com` 即可，白名单会自动清掉。

**Q：要不要备案？**

`IP + 非标端口` 这条路不需要，也没有域名可备。
但严格讲，面向公众提供 UGC 服务（玩家投稿）在国内属于需要备案和内容管理的范畴。
小范围分享（几十人）现实中不会有人管；真要对外推广，建议补备案并保持审核流程。

**Q：一个能扛多少人？**

这套是单进程同步 SQLite，实测单次查询在 1ms 内。
几百人的日常使用（每天几千次请求）毫无压力。真正的瓶颈是 3M 带宽，不是数据库。

**Q：服务挂了会自动重启吗？**

会。systemd 配了 `Restart=always`，崩溃 3 秒后自动拉起，开机自启。

---

## 文件说明

```
arkham-api/
├── worker.js                  服务端全部逻辑（与 Cloudflare 版完全同一份）
├── schema.sql                 建表语句（幂等，每次启动执行）
├── seed.sql                   6 套 ArkhamDB 参考牌组
├── package.json               声明 ESM
└── node/
    ├── server.mjs             HTTP 入口：node:http ↔ Request/Response
    ├── d1.mjs                 D1 → node:sqlite 适配（bind/first/all/run）
    ├── start.sh               启动（按 Node 版本决定要不要 --experimental-sqlite）
    ├── install.sh             一键安装
    ├── backup.sh              备份
    ├── arkham-api.service     systemd 单元
    └── data/arkham.db         数据库（装完才有）
```
