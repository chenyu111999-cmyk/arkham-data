/**
 * D1 → node:sqlite 适配层。
 *
 * 只实现 worker.js 真正用到的四个方法：bind / first / all / run。
 * 语义对齐 Cloudflare D1：
 *   first()  无行返回 null（node:sqlite 返回 undefined，必须转）
 *   all()    返回 { results: [...] }
 *   run()    返回 { success, meta: { changes } }
 *
 * 参数里出现 undefined 一律转 null —— node:sqlite 不认 undefined，
 * 而 D1 的 bind(undefined) 等价于绑 NULL。
 */
import { DatabaseSync } from "node:sqlite";
import { readFileSync, mkdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = join(HERE, "..");

/** 打开（或创建）数据库文件，并设置对单机服务重要的三个 pragma */
export function openDb(file) {
  if (file !== ":memory:") mkdirSync(dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  // WAL：读写不互相阻塞，App 拉列表时投票不会卡
  db.exec("PRAGMA journal_mode = WAL");
  // NORMAL 在 WAL 下已足够安全，比 FULL 快一个量级
  db.exec("PRAGMA synchronous = NORMAL");
  // 万一有多进程（比如备份脚本），最多等 5 秒而不是立刻抛 SQLITE_BUSY
  db.exec("PRAGMA busy_timeout = 5000");
  return db;
}

/** 建表 + 灌种子数据；两个脚本都是幂等的，每次启动执行无害 */
export function initDb(db) {
  db.exec(readFileSync(join(ROOT, "schema.sql"), "utf8"));
  db.exec(readFileSync(join(ROOT, "seed.sql"), "utf8"));
}

function norm(v) {
  if (v === undefined) return null;
  if (typeof v === "boolean") return v ? 1 : 0;
  return v;
}

export function d1(db) {
  // 同一条 SQL 反复编译是浪费，按语句文本缓存；同步驱动所以复用安全
  const cache = new Map();

  function stmtOf(sql) {
    let s = cache.get(sql);
    if (!s) {
      s = db.prepare(sql);
      if (cache.size > 64) cache.clear();
      cache.set(sql, s);
    }
    return s;
  }

  function prepare(sql) {
    let params = [];
    const api = {
      bind(...a) {
        params = a.map(norm);
        return api;
      },
      async first(col) {
        const row = stmtOf(sql).get(...params);
        if (row === undefined) return null;
        return col ? (row[col] === undefined ? null : row[col]) : row;
      },
      async all() {
        return { results: stmtOf(sql).all(...params), success: true };
      },
      async run() {
        const r = stmtOf(sql).run(...params);
        return {
          success: true,
          meta: {
            changes: Number(r.changes || 0),
            last_row_id: Number(r.lastInsertRowid || 0),
          },
        };
      },
      // worker.js 没用到，留着防止将来加接口时踩空
      async raw() {
        const rows = stmtOf(sql).all(...params);
        return rows.map((r) => Object.values(r));
      },
    };
    return api;
  }

  return { prepare, exec: async (sql) => { db.exec(sql); return { count: 0 }; } };
}
