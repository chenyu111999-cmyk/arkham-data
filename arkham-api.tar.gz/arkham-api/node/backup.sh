#!/usr/bin/env bash
# 备份数据库。VACUUM INTO 会顺带压实，比直接 cp 安全（WAL 模式下 cp 可能拿到半个事务）。
#
#   bash backup.sh
#   DB_PATH=/path/to.db BACKUP_DIR=/path/to/dir bash backup.sh
set -euo pipefail

DB=${DB_PATH:-/opt/arkham-api/node/data/arkham.db}
DIR=${BACKUP_DIR:-/opt/arkham-api/backup}
KEEP_DAYS=${KEEP_DAYS:-30}

[ -f "$DB" ] || { echo "找不到数据库：$DB" >&2; exit 1; }
mkdir -p "$DIR"

TS=$(date +%Y%m%d-%H%M%S)
OUT="$DIR/arkham-$TS.db"

# VACUUM INTO 的路径只能写成 SQL 字符串字面量（单引号），不能绑参数
sql_lit() { printf "'%s'" "$(printf '%s' "$1" | sed "s/'/''/g")"; }

node -e '
const { DatabaseSync } = require("node:sqlite");
const [db, out] = process.argv.slice(1);
const d = new DatabaseSync(db);
d.exec("VACUUM INTO " + out);
d.close();
' "$DB" "$(sql_lit "$OUT")" 2>/dev/null || {
  # Node 22 早期版本需要显式开关
  node --experimental-sqlite -e '
  const { DatabaseSync } = require("node:sqlite");
  const [db, out] = process.argv.slice(1);
  const d = new DatabaseSync(db);
  d.exec("VACUUM INTO " + out);
  d.close();
  ' "$DB" "$(sql_lit "$OUT")"
}

gzip -f "$OUT"
find "$DIR" -name 'arkham-*.db.gz' -mtime +"$KEEP_DAYS" -delete

echo "已备份：$OUT.gz（$(du -h "$OUT.gz" | cut -f1)）"
